def snake():
    print("This is from another module!")